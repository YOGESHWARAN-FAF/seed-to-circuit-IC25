// Main JavaScript for Seed2Circuit

document.addEventListener('DOMContentLoaded', function() {
    console.log('Seed2Circuit App Loaded');
    
    // Add your JavaScript functionality here
});

// Utility function for API calls
async function fetchAPI(url, options = {}) {
    try {
        const response = await fetch(url, options);
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}
