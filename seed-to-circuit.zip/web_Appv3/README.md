# 🌾 Seed-to-Circuit: Smart Agricultural Management System

A comprehensive IoT-enabled agricultural platform that connects farmers and vendors through real-time monitoring, AI-powered insights, and marketplace functionality.

## 🚀 Features

### For Farmers
- **Real-time Field Monitoring**: IoT sensor integration for soil NPK, moisture, temperature, and pH
- **AI Disease Detection**: Gemini AI-powered plant disease identification and treatment recommendations
- **Growth Stage Tracking**: Monitor crop development with timeline predictions
- **Market Price Analysis**: Live vegetable market prices and trends
- **Bidding System**: Sell crops directly to vendors through auction platform
- **WhatsApp Integration**: Receive automated reports and notifications
- **Multi-language Support**: Tamil and English interface

### For Vendors
- **Crop Marketplace**: Browse and bid on farmer listings
- **Real-time Notifications**: SMS alerts for new bidding opportunities
- **Location-based Sourcing**: Find farmers in specific regions
- **Quality Assessment**: View crop quality ratings and sensor data

### Smart Features
- **Doctor AI**: Comprehensive plant health analysis with treatment schedules
- **Profit Calculator**: ROI analysis for different crops
- **Labor Management**: Connect with agricultural workers
- **Weather Integration**: Historical and current climate data
- **Crop Recommendations**: AI-suggested crops based on soil conditions

## 🛠️ Technology Stack

- **Backend**: Flask (Python)
- **Database**: Firebase Realtime Database
- **Authentication**: Firebase Auth
- **AI/ML**: Google Gemini 2.0 Flash
- **IoT**: ThingSpeak integration
- **Messaging**: Twilio SMS
- **Frontend**: HTML, CSS, JavaScript
- **APIs**: Weather API, News API, Market Data

## 📋 Prerequisites

- Python 3.8+
- Firebase project with Realtime Database
- Google Gemini API key
- Twilio account (for SMS)
- ThingSpeak channel (for IoT data)

## ⚙️ Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd web_Appv3
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Environment Setup**
Create `.env` file:
```env
FIREBASE_API_KEY=your_firebase_api_key
SECRET_KEY=your_secret_key
GEMINI_API_KEY=your_gemini_api_key
GEMINI_API_KEY_2=your_secondary_gemini_key
NEWS_API_KEY=your_news_api_key
THINGSPEAK_API_KEY=your_thingspeak_key
THINGSPEAK_CHANNEL_ID=your_channel_id
WEATHER_API_KEY=your_weather_api_key
```

4. **Firebase Configuration**
- Place your Firebase service account JSON in `config/` directory
- Update the path in `app.py`

5. **Run the application**
```bash
python app.py
```

## 🏗️ Project Structure

```
web_Appv3/
├── app.py                 # Main Flask application
├── doctor.py             # AI disease analysis module
├── farmer_report.py      # Report generation
├── market_scraper.py     # Market price scraping
├── sensor_reader.py      # IoT sensor data handling
├── templates/            # HTML templates
├── static/              # CSS, JS, images
├── config/              # Firebase credentials
├── uploads/             # File uploads
└── gvtdata.json         # Government recommendations
```

## 🔧 Key Components

### Authentication System
- Separate farmer and vendor registration/login
- Session-based user type management
- Firebase Auth integration

### IoT Integration
```python
# ThingSpeak sensor data
sensor = SensorReader(THINGSPEAK_API)
data = sensor.get_latest_data()
```

### AI Analysis
```python
# Gemini AI for crop analysis
doctor_ai = DoctorAI(api_key="your_key")
results = doctor_ai.analyze_all_fields(field_data)
```

### Real-time Data Storage
```python
# Firebase data structure
signup/users/{uid}/data/{field}/{timestamp}/
vendor/{uid}/
```

## 📱 API Endpoints

### Farmer Routes
- `POST /sign_in` - Farmer registration
- `POST /sign-up` - Farmer login
- `POST /webhook/user_data` - Store field data
- `GET /index/role/main` - Farmer dashboard

### Vendor Routes
- `POST /v-sign_in` - Vendor registration
- `POST /v-sign-up` - Vendor login
- `POST /vendor/login` - Vendor session validation
- `GET /vendor_buy` - Vendor marketplace

### Data Routes
- `GET /field-datas` - Fetch field data
- `POST /bidding` - Create crop listing
- `POST /webhook3` - Process vendor bids

## 🌐 Deployment

1. **Environment Variables**: Set all required API keys
2. **Firebase Setup**: Configure database rules
3. **Domain Configuration**: Update CORS settings
4. **SSL Certificate**: Enable HTTPS for production

## 🔒 Security Features

- Token-based authentication
- User type validation
- Session management
- Input sanitization
- File upload security

## 📊 Data Flow

1. **IoT Sensors** → ThingSpeak → Flask App
2. **User Input** → Firebase → AI Analysis
3. **Market Data** → Web Scraping → Dashboard
4. **Notifications** → Twilio SMS → Users

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 📞 Support

For support and queries:
- Email: support@seedtocircuit.com
- Documentation: [Project Wiki]
- Issues: [GitHub Issues]

## 🙏 Acknowledgments

- Google Gemini AI for intelligent crop analysis
- Firebase for real-time database
- ThingSpeak for IoT integration
- Twilio for messaging services