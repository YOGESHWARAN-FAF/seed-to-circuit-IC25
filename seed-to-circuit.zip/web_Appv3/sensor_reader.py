import requests

class SensorReader:
    def __init__(self, api_url):
        self.api_url = api_url

    # Helper function to safely convert to float
    def safe_float(self, value):
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0

    # Fetch latest data and apply calibration
    def get_latest_data(self):
        response = requests.get(self.api_url)
        if response.status_code != 200:
            print("Failed to fetch data:", response.status_code)
            return None

        data = response.json()
        if not data['feeds']:
            print("No data found in ThingSpeak channel.")
            return None

        latestEntry = data['feeds'][0]

        # Raw sensor values
        rawN = self.safe_float(latestEntry.get('field1'))
        rawP = self.safe_float(latestEntry.get('field2'))
        rawK = self.safe_float(latestEntry.get('field3'))
        rawPH = self.safe_float(latestEntry.get('field4'))
        rawMoisture = self.safe_float(latestEntry.get('field5'))
        rawCO2 = self.safe_float(latestEntry.get('field6'))
        rawHumidity = self.safe_float(latestEntry.get('field7'))
        rawSoilTemp = self.safe_float(latestEntry.get('field8'))

        # Apply calibration formulas
        calibratedData = {
            "nitrogen": round(rawN * 15, 2),
            "phosphorus": round(rawP * 1, 2),
            "potassium": round(rawK * 3.5, 2),
            "ph": round(rawPH, 2),
            "moisture": round(rawMoisture, 2),
            "co2": round(rawCO2, 2),
            "humidity": round(rawHumidity, 2),
            "soil_temperature": round(rawSoilTemp, 2),
            "timestamp": latestEntry.get('created_at')
        }

        return calibratedData
