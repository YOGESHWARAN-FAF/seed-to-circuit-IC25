import json
import requests
import time
from datetime import datetime, timedelta
from twilio.rest import Client

# ------------------- File Path -------------------
ERROR_FILE = r"E:\sprintathon\web_Appv3\errors.json"  # Update path if needed

# ------------------- ThingSpeak Details -------------------
CHANNEL_ID = "3083591"
READ_API_KEY = "H019XD400HQKTTXR"
FIELD_NUMBER = "field1"  # Fault code field

# ------------------- Twilio Details -------------------
TWILIO_ACCOUNT_SID = "AC72f5c002f30c86b28b8144cdf835dd7f"
TWILIO_AUTH_TOKEN = "1315459277894193de40c9353415c9bc"
TWILIO_MESSAGING_SERVICE_SID = "MGe50eeb89e8b4e44c079104a0df6bbfab"
TO_NUMBER = "+918681047769"

client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

# ------------------- Load JSON Fault Data -------------------
def load_fault_data():
    try:
        with open(ERROR_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("faultCodes", {})
    except Exception as e:
        print("❌ Error loading JSON file:", e)
        return {}

# ------------------- Send SMS -------------------
def send_sms(fault_code, timestamp, description, status):
    # Choose color/status emoji
    emoji = "✅" if status == "Green" else "🟡" if status == "Yellow" else "🔴"
    message_body = (
        f"⚡ Alert from S2C! 🕒 {timestamp} {emoji} Fault Code: {fault_code} "
        f"- {description} (Status: {status}). 📞 Contact S2C Customer Care."
    )
    message = client.messages.create(
        messaging_service_sid=TWILIO_MESSAGING_SERVICE_SID,
        to=TO_NUMBER,
        body=message_body
    )
    print(f"✅ SMS sent for fault code {fault_code}. SID: {message.sid}")

# ------------------- Main Monitoring Function -------------------
def main():
    fault_data = load_fault_data()
    if not fault_data:
        print("⚠️ No fault data loaded from JSON.")
        return

    print("✅ JSON fault codes loaded successfully.")
    last_sms_time = None
    SMS_COOLDOWN = timedelta(hours=24)

    while True:
        try:
            url = f"https://api.thingspeak.com/channels/{CHANNEL_ID}/feeds.json?api_key={READ_API_KEY}&results=1"
            response = requests.get(url)

            if response.status_code == 200:
                feeds = response.json().get("feeds", [])
                if feeds:
                    latest = feeds[-1]
                    timestamp = latest.get("created_at")
                    fault_value = latest.get(FIELD_NUMBER)

                    if fault_value is not None:
                        fault_code = int(float(fault_value))
                        fault_info = fault_data.get(str(fault_code))

                        if fault_info:
                            description = fault_info["description"]
                            status = fault_info["status"]
                        else:
                            description = "Unknown fault code"
                            status = "Unknown"

                        print(f"🕒 {timestamp} | Code: {fault_code} → {description} | Status: {status}")

                        # Send SMS only for faults (not code 0)
                        if fault_code != 0:
                            now = datetime.now()
                            if last_sms_time is None or (now - last_sms_time) >= SMS_COOLDOWN:
                                send_sms(fault_code, timestamp, description, status)
                                last_sms_time = now
                            else:
                                print("⏳ SMS already sent within 24 hours. Skipping...")
                        else:
                            print("✅ All systems OK. No fault detected.")
                    else:
                        print("⚠️ No fault code found in ThingSpeak data.")
            else:
                print(f"❌ Failed to fetch ThingSpeak data. Status: {response.status_code}")

            time.sleep(60)  # Check every 60 seconds

        except Exception as e:
            print("❌ Error:", e)
            time.sleep(60)

# ------------------- Run -------------------
if __name__ == "__main__":
    main()
