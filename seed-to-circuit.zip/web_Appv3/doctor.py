"""
DoctorAI: Plant Growth & Disease Analyzer
(Gemini 2.0 Flash + Real-time Data + OOP)
"""

import google.generativeai as genai


class DoctorAI:
    def __init__(self, api_key):
        """Initialize Gemini configuration"""
        self.api_key = api_key
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel("gemini-2.0-flash")

    def analyze_single_field(self, frontend_data, sensor_data):
        """
        Analyze single field data using Gemini AI.
        """
        prompt = f"""
        You are an expert agronomist and IoT data analyst.
        Analyze the dataset below and produce a structured JSON report.

        1. Identify the plant stage from 'growthStage' and timestamp.
        2. Confirm disease and give short treatment recommendations.
        3. Evaluate these 8 parameters:
            - nitrogen (N)
            - phosphorus (P)
            - potassium (K)
            - ph
            - moisture
            - humidity
            - co2
            - soil_temperature
        4. From all data, estimate:
            - how many days plant has been in current stage
            - expected total growth period
            - timeline (daily growth actions)
            - treatment schedule (what & when to apply)

        Return strictly in JSON format:
        {{
          "field": "...",
          "identified_stage": "...",
          "disease": "...",
          "sensor_summary": {{...}},
          "timeline": [{{"day": 1, "action": "..."}} , ...],
          "treatments": [{{"day": "date", "action": "..."}}],
          "days":[number of stage days to harvest (numbers only)],
          "notes": "• 💊 Current Status:
  - Mention the present condition of the plant (e.g., healthy, recovering, still affected).
  - Specify if it is affected or improving after treatment.

• 🌾 Recommended Fertilizer / Pesticide:
  - List the most suitable fertilizer or pesticide for the current growth stage or disease.
  - Include dosage or application frequency (if known).

• ⏳ Days Left to Harvest:
  - Provide an estimated number of days remaining before harvest(give in number  of days ).

• 🌱 Additional Tips for Fast Growth:
  - Suggest practical tips to enhance growth speed.
  - Include watering, sunlight, or soil improvement advice.






"
        }}

        FRONTEND_DATA = {frontend_data}
        SENSOR_DATA = {sensor_data}
        """

        try:
            response = self.model.generate_content(prompt)
            return response.text
        except Exception as e:
            return f"Error analyzing field: {str(e)}"

    def analyze_all_fields(self, field_data_list):
        """
        Analyze multiple fields in a list.
        """
        all_results = []
        for entry in field_data_list:
            frontend = {
                "field": entry.get("field"),
                "disease": entry.get("disease"),
                "growthStage": entry.get("growthStage"),
                "timestamp": entry.get("timestamp"),
            }
            sensor = entry.get("sensor_data", {})

            print(f"🧠 Analyzing {frontend['field']} using Gemini...")
            result = self.analyze_single_field(frontend, sensor)
            all_results.append({
                "field": frontend["field"],
                "ai_result": result
            })

        return all_results
